#include "VectorConstants.h"
#include "NumberConstants.h"

const Vector ZERO_VECTOR(ZERO, ZERO);
const Vector UNIT_VECTOR_DIAGONAL(ONE, ONE);