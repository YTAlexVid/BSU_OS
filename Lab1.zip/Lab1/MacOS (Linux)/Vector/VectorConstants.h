//
// Created by Alex Saharchuk on 30/09/2025.
//

#ifndef VECTORCONSTANTS_H
#define VECTORCONSTANTS_H

#include "Vector.h"

extern const Vector VECTOR_API ZERO_VECTOR;
extern const Vector VECTOR_API UNIT_VECTOR_DIAGONAL;

#endif //VECTORCONSTANTS_H
