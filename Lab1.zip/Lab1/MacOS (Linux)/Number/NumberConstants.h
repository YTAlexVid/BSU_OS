//
// Created by Alex Saharchuk on 24/09/2025.
//

#ifndef NUMBERCONSTANTS_H
#define NUMBERCONSTANTS_H

#include "Number.h"

const Number ZERO(0);
const Number ONE(1);

#endif //NUMBERCONSTANTS_H
