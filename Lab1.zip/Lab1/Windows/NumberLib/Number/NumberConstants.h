#pragma once
#include "Number.h"

const Number ZERO(0);
const Number ONE(1);
