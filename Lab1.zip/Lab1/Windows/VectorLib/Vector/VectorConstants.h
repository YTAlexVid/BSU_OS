#pragma once

#include "Vector.h"

extern const Vector VECTOR_API ZERO_VECTOR;
extern const Vector VECTOR_API UNIT_VECTOR_DIAGONAL;